tellraw @s [{"text": "[The Chief Cogwright] ", "color": "gold", "bold": true}, {"text": "We measure things. That is the whole philosophy. If a thing cannot be measured, we have not built the instrument yet.", "color": "white", "italic": false}]
tellraw @s [{"text": "[The Chief Cogwright] ", "color": "gold", "bold": true}, {"text": "Eight precision mechanisms. You cannot buy these. You cannot dig these. You will have to BUILD something that makes them, and that is the actual test.", "color": "yellow", "italic": false}]
tellraw @s [{"text": "  Quest 13/15 — bring 8 Precision Mechanisms  $(4)[Create — build a factory]$() to The Chief Cogwright.", "color": "gray", "italic": true}]
advancement grant @s only aurn:quest/aldergear/started
playsound minecraft:entity.villager.yes master @s ~ ~ ~ 1 1
