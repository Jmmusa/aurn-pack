# Sazane — Lorekeeper router
execute unless entity @s[advancements={aurn:quest/sazane/started=true}] run function aurn:quest/sazane/start
execute if entity @s[advancements={aurn:quest/sazane/started=true}] unless entity @s[advancements={aurn:quest/sazane/done=true}] run function aurn:quest/sazane/check
execute if entity @s[advancements={aurn:quest/sazane/done=true}] run function aurn:quest/sazane/after
