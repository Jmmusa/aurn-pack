tellraw @s [{"text": "[Cartographer Yset] ", "color": "gold", "bold": true}, {"text": "We have said what we had to say. Go west. Or north. Somewhere else.", "color": "gray", "italic": true}]
