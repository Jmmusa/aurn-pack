clear @s minecraft:book 32
tellraw @s [{"text": "[The Licensed Archivist] ", "color": "gold", "bold": true}, {"text": "The third version was filed once, by a clerk who did not survive the week. I have read it. It does not describe a scream. It describes an ANSWER, and it describes who asked.", "color": "white", "italic": false}]
tellraw @s [{"text": "  The Licensed Archivist gives you half-armour, a bascinet and bottled experience.", "color": "green", "italic": true}]
give @s magistuarmory:halfarmor_chestplate
give @s magistuarmory:bascinet
give @s minecraft:experience_bottle 32
advancement grant @s only aurn:quest/twin_crown/done
playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1 1
