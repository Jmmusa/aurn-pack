# The Grokh — Lorekeeper router
execute unless entity @s[advancements={aurn:quest/grokh/started=true}] run function aurn:quest/grokh/start
execute if entity @s[advancements={aurn:quest/grokh/started=true}] unless entity @s[advancements={aurn:quest/grokh/done=true}] run function aurn:quest/grokh/check
execute if entity @s[advancements={aurn:quest/grokh/done=true}] run function aurn:quest/grokh/after
