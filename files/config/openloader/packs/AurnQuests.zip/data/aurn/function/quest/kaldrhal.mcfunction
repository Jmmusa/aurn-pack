# Kaldrhal — Lorekeeper router
execute unless entity @s[advancements={aurn:quest/kaldrhal/started=true}] run function aurn:quest/kaldrhal/start
execute if entity @s[advancements={aurn:quest/kaldrhal/started=true}] unless entity @s[advancements={aurn:quest/kaldrhal/done=true}] run function aurn:quest/kaldrhal/check
execute if entity @s[advancements={aurn:quest/kaldrhal/done=true}] run function aurn:quest/kaldrhal/after
