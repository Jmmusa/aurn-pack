clear @s minecraft:deepslate 128
tellraw @s [{"text": "[The Rememberer] ", "color": "gold", "bold": true}, {"text": "We are what is left of the ones who asked. Not descendants. LEFT. We did not die and we did not change and we have not been able to stop remembering the answer since the moment it was given.", "color": "white", "italic": false}]
tellraw @s [{"text": "  The Rememberer gives you a crusader plate, a greathelm and a greathammer.", "color": "green", "italic": true}]
give @s magistuarmory:crusader_chestplate
give @s magistuarmory:greathelm
give @s simplyswords:iron_greathammer
advancement grant @s only aurn:quest/grokh/done
playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1 1
