tellraw @s [{"text": "[Cartographer Yset] ", "color": "gold", "bold": true}, {"text": "There are eight Listening Spires. Every map shows eight. I drew most of those maps.", "color": "white", "italic": false}]
tellraw @s [{"text": "[Cartographer Yset] ", "color": "gold", "bold": true}, {"text": "Forty-eight paper. A cartographer without paper is just a man with opinions.", "color": "yellow", "italic": false}]
tellraw @s [{"text": "  Quest 6/15 — bring 48 Paper to Cartographer Yset.", "color": "gray", "italic": true}]
advancement grant @s only aurn:quest/nasiri/started
playsound minecraft:entity.villager.yes master @s ~ ~ ~ 1 1
