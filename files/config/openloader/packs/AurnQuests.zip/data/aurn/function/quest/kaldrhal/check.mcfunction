execute store result score @s aurn_cnt run clear @s minecraft:blue_ice 0
execute if score @s aurn_cnt matches 16.. run function aurn:quest/kaldrhal/complete
execute if score @s aurn_cnt matches ..15 run tellraw @s [{"text": "[The Frost-Warden] ", "color": "gold", "bold": true}, {"text": "Sixteen blue ice. Cut it yourself. Ice given is not ice earned.", "color": "yellow", "italic": false}]
execute if score @s aurn_cnt matches ..15 run tellraw @s [{"text": "  Still needed: ", "color": "gray", "italic": true}, {"text": "16 Blue Ice", "color": "yellow", "italic": true}, {"text": "   (you have ", "color": "gray", "italic": true}, {"score": {"name": "@s", "objective": "aurn_cnt"}, "color": "white"}, {"text": ")", "color": "gray", "italic": true}]
