# Isar-Thal — Lorekeeper router
execute unless entity @s[advancements={aurn:quest/isar_thal/started=true}] run function aurn:quest/isar_thal/start
execute if entity @s[advancements={aurn:quest/isar_thal/started=true}] unless entity @s[advancements={aurn:quest/isar_thal/done=true}] run function aurn:quest/isar_thal/check
execute if entity @s[advancements={aurn:quest/isar_thal/done=true}] run function aurn:quest/isar_thal/after
