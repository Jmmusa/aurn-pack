tellraw @s [{"text": "[Root-Speaker Aell] ", "color": "gold", "bold": true}, {"text": "The World Tree and the Death Serpent are enemies. Everyone knows that. Everyone. Knows. That.", "color": "white", "italic": false}]
tellraw @s [{"text": "[Root-Speaker Aell] ", "color": "gold", "bold": true}, {"text": "Twenty-four honeycomb. Take it kindly or the grove notices.", "color": "yellow", "italic": false}]
tellraw @s [{"text": "  Quest 4/15 — bring 24 Honeycomb to Root-Speaker Aell.", "color": "gray", "italic": true}]
advancement grant @s only aurn:quest/sylvani/started
playsound minecraft:entity.villager.yes master @s ~ ~ ~ 1 1
