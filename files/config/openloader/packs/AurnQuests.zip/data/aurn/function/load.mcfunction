scoreboard objectives add aurn_rng dummy
scoreboard objectives add aurn_cnt dummy
