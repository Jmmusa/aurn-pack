tellraw @s [{"text": "[The Seam-Finder] ", "color": "gold", "bold": true}, {"text": "Out here we find seams. Cracks in things. Most are in rock. A few are not.", "color": "white", "italic": false}]
tellraw @s [{"text": "[The Seam-Finder] ", "color": "gold", "bold": true}, {"text": "Sixteen gold. I do not care where from. Out here nobody asks.", "color": "yellow", "italic": false}]
tellraw @s [{"text": "  Quest 5/15 — bring 16 Gold Ingots to The Seam-Finder.", "color": "gray", "italic": true}]
advancement grant @s only aurn:quest/dust_hollow/started
playsound minecraft:entity.villager.yes master @s ~ ~ ~ 1 1
