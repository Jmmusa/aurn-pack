# Twin-Crown — Lorekeeper router
execute unless entity @s[advancements={aurn:quest/twin_crown/started=true}] run function aurn:quest/twin_crown/start
execute if entity @s[advancements={aurn:quest/twin_crown/started=true}] unless entity @s[advancements={aurn:quest/twin_crown/done=true}] run function aurn:quest/twin_crown/check
execute if entity @s[advancements={aurn:quest/twin_crown/done=true}] run function aurn:quest/twin_crown/after
