tellraw @s [{"text": "[The Bell-Warden] ", "color": "gold", "bold": true}, {"text": "We bred a listener once. On purpose. It was supposed to hear the Deep Heart and tell us what it said.", "color": "white", "italic": false}]
tellraw @s [{"text": "[The Bell-Warden] ", "color": "gold", "bold": true}, {"text": "Thirty-two prismarine crystals. From the monument, not the shallows.", "color": "yellow", "italic": false}]
tellraw @s [{"text": "  Quest 11/15 — bring 32 Prismarine Crystals to The Bell-Warden.", "color": "gray", "italic": true}]
advancement grant @s only aurn:quest/isar_thal/started
playsound minecraft:entity.villager.yes master @s ~ ~ ~ 1 1
