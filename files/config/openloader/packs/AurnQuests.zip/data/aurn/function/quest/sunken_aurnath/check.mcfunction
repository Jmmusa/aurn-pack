execute store result score @s aurn_cnt run clear @s minecraft:echo_shard 0
execute if score @s aurn_cnt matches 12.. run function aurn:quest/sunken_aurnath/complete
execute if score @s aurn_cnt matches ..11 run tellraw @s [{"text": "[The Archivist of the Drowned] ", "color": "gold", "bold": true}, {"text": "Twelve echo shards. From the deep dark. Bring a light and do not run.", "color": "yellow", "italic": false}]
execute if score @s aurn_cnt matches ..11 run tellraw @s [{"text": "  Still needed: ", "color": "gray", "italic": true}, {"text": "12 Echo Shards  $(4)[Deep Dark]$()", "color": "yellow", "italic": true}, {"text": "   (you have ", "color": "gray", "italic": true}, {"score": {"name": "@s", "objective": "aurn_cnt"}, "color": "white"}, {"text": ")", "color": "gray", "italic": true}]
