# Kharuun — Lorekeeper router
execute unless entity @s[advancements={aurn:quest/kharuun/started=true}] run function aurn:quest/kharuun/start
execute if entity @s[advancements={aurn:quest/kharuun/started=true}] unless entity @s[advancements={aurn:quest/kharuun/done=true}] run function aurn:quest/kharuun/check
execute if entity @s[advancements={aurn:quest/kharuun/done=true}] run function aurn:quest/kharuun/after
