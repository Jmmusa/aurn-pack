clear @s minecraft:echo_shard 12
tellraw @s [{"text": "[The Archivist of the Drowned] ", "color": "gold", "bold": true}, {"text": "They did not drown. They went down deliberately, because the sound is quieter under water, and they have been waiting for it to finish. It has not finished. We are still inside it.", "color": "white", "italic": false}]
tellraw @s [{"text": "  The Archivist of the Drowned gives you full platemail, a maximilian helm and a notched apple.", "color": "green", "italic": true}]
give @s magistuarmory:platemail_chestplate
give @s magistuarmory:maximilian_helmet
give @s minecraft:enchanted_golden_apple
advancement grant @s only aurn:quest/sunken_aurnath/done
playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1 1
