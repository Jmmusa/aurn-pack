tellraw @s [{"text": "[The Lantern-Keeper] ", "color": "gold", "bold": true}, {"text": "We have said what we had to say. Go west. Or north. Somewhere else.", "color": "gray", "italic": true}]
