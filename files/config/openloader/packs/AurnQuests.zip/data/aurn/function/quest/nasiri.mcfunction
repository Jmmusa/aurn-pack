# Nasiri — Lorekeeper router
execute unless entity @s[advancements={aurn:quest/nasiri/started=true}] run function aurn:quest/nasiri/start
execute if entity @s[advancements={aurn:quest/nasiri/started=true}] unless entity @s[advancements={aurn:quest/nasiri/done=true}] run function aurn:quest/nasiri/check
execute if entity @s[advancements={aurn:quest/nasiri/done=true}] run function aurn:quest/nasiri/after
