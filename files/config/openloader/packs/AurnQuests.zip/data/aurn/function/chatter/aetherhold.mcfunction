scoreboard players set @s aurn_rng 0
execute store result score @s aurn_rng run random value 1..5
execute if score @s aurn_rng matches 1 run tellraw @s [{"text": "[Villager] ", "color": "gold", "bold": true}, {"text": "Move along.", "color": "white", "italic": false}]
execute if score @s aurn_rng matches 2 run tellraw @s [{"text": "[Villager] ", "color": "gold", "bold": true}, {"text": "Not interested.", "color": "white", "italic": false}]
execute if score @s aurn_rng matches 3 run tellraw @s [{"text": "[Villager] ", "color": "gold", "bold": true}, {"text": "Cold today.", "color": "white", "italic": false}]
execute if score @s aurn_rng matches 4 run tellraw @s [{"text": "[Villager] ", "color": "gold", "bold": true}, {"text": "Talk to the one in the good coat. They know things.", "color": "white", "italic": false}]
execute if score @s aurn_rng matches 5 run tellraw @s [{"text": "[Villager] ", "color": "gold", "bold": true}, {"text": "Buy or don't.", "color": "white", "italic": false}]
