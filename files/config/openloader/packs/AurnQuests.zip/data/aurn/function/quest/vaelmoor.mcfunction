# Vaelmoor — Lorekeeper router
execute unless entity @s[advancements={aurn:quest/vaelmoor/started=true}] run function aurn:quest/vaelmoor/start
execute if entity @s[advancements={aurn:quest/vaelmoor/started=true}] unless entity @s[advancements={aurn:quest/vaelmoor/done=true}] run function aurn:quest/vaelmoor/check
execute if entity @s[advancements={aurn:quest/vaelmoor/done=true}] run function aurn:quest/vaelmoor/after
