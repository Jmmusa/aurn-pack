tellraw @s [{"text": "[The Rememberer] ", "color": "gold", "bold": true}, {"text": "You will hear fifteen beginnings before you are done. We do not have a version. We have a memory. There is a difference.", "color": "white", "italic": false}]
tellraw @s [{"text": "[The Rememberer] ", "color": "gold", "bold": true}, {"text": "One hundred and twenty-eight deepslate. Cut from below the old line. You will know it when your pick goes quiet.", "color": "yellow", "italic": false}]
tellraw @s [{"text": "  Quest 10/15 — bring 128 Deepslate to The Rememberer.", "color": "gray", "italic": true}]
advancement grant @s only aurn:quest/grokh/started
playsound minecraft:entity.villager.yes master @s ~ ~ ~ 1 1
