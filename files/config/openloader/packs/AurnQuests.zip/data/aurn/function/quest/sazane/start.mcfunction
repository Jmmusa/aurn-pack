tellraw @s [{"text": "[The Petal-Sworn] ", "color": "gold", "bold": true}, {"text": "Everything beautiful in this kingdom is also a weapon. That is not a warning. It is just the arrangement.", "color": "white", "italic": false}]
tellraw @s [{"text": "[The Petal-Sworn] ", "color": "gold", "bold": true}, {"text": "Thirty-two petals. Cut, not fallen. Fallen petals have already given up.", "color": "yellow", "italic": false}]
tellraw @s [{"text": "  Quest 7/15 — bring 32 Pink Petals to The Petal-Sworn.", "color": "gray", "italic": true}]
advancement grant @s only aurn:quest/sazane/started
playsound minecraft:entity.villager.yes master @s ~ ~ ~ 1 1
