clear @s minecraft:honeycomb 24
tellraw @s [{"text": "[Root-Speaker Aell] ", "color": "gold", "bold": true}, {"text": "I have followed the roots down for two hundred years. I have followed the coils up. They meet. They do not fight when they meet. I have stopped telling people this.", "color": "white", "italic": false}]
tellraw @s [{"text": "  Root-Speaker Aell gives you lamellar armour and an iron glaive.", "color": "green", "italic": true}]
give @s magistuarmory:lamellar_chestplate
give @s simplyswords:iron_glaive
give @s minecraft:arrow 64
advancement grant @s only aurn:quest/sylvani/done
playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1 1
