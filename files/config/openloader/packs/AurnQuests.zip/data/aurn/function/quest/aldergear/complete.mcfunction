clear @s create:precision_mechanism 8
tellraw @s [{"text": "[The Chief Cogwright] ", "color": "gold", "bold": true}, {"text": "We built the instrument. It measures the sound. The needle has not moved in four hundred years, which we reported as a fault. It is not a fault. The sound has not changed since it started.", "color": "white", "italic": false}]
tellraw @s [{"text": "  The Chief Cogwright gives you maximilian plate, a cuirassier helm and the Emberblade.", "color": "green", "italic": true}]
give @s magistuarmory:maximilian_chestplate
give @s magistuarmory:cuirassier_helmet
give @s simplyswords:emberblade
advancement grant @s only aurn:quest/aldergear/done
playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1 1
