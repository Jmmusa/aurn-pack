scoreboard players set @s aurn_rng 0
execute store result score @s aurn_rng run random value 1..5
execute if score @s aurn_rng matches 1 run tellraw @s [{"text": "[Villager] ", "color": "gold", "bold": true}, {"text": "Mind the third shaft. Just mind it.", "color": "white", "italic": false}]
execute if score @s aurn_rng matches 2 run tellraw @s [{"text": "[Villager] ", "color": "gold", "bold": true}, {"text": "Everything's in the ledger. EVERYTHING.", "color": "white", "italic": false}]
execute if score @s aurn_rng matches 3 run tellraw @s [{"text": "[Villager] ", "color": "gold", "bold": true}, {"text": "You've got soft hands. No shame in it.", "color": "white", "italic": false}]
execute if score @s aurn_rng matches 4 run tellraw @s [{"text": "[Villager] ", "color": "gold", "bold": true}, {"text": "We stopped digging at the eighth seam. Ask the Keeper why.", "color": "white", "italic": false}]
execute if score @s aurn_rng matches 5 run tellraw @s [{"text": "[Villager] ", "color": "gold", "bold": true}, {"text": "Ale's warm, stone's cold. Balance.", "color": "white", "italic": false}]
