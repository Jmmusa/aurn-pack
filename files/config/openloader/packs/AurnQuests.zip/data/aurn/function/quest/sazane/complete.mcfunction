clear @s minecraft:pink_petals 32
tellraw @s [{"text": "[The Petal-Sworn] ", "color": "gold", "bold": true}, {"text": "We keep gardens over the graves of the ones who listened too long. The flowers there grow in a spiral. We did not plant them in a spiral.", "color": "white", "italic": false}]
tellraw @s [{"text": "  The Petal-Sworn gives you ceremonial plate, a rapier and healing draughts.", "color": "green", "italic": true}]
give @s magistuarmory:ceremonial_chestplate
give @s simplyswords:iron_rapier
give @s minecraft:potion[minecraft:potion_contents={potion:'minecraft:strong_healing'}] 3
advancement grant @s only aurn:quest/sazane/done
playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1 1
