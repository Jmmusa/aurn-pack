# Aldergear — Lorekeeper router
execute unless entity @s[advancements={aurn:quest/aldergear/started=true}] run function aurn:quest/aldergear/start
execute if entity @s[advancements={aurn:quest/aldergear/started=true}] unless entity @s[advancements={aurn:quest/aldergear/done=true}] run function aurn:quest/aldergear/check
execute if entity @s[advancements={aurn:quest/aldergear/done=true}] run function aurn:quest/aldergear/after
