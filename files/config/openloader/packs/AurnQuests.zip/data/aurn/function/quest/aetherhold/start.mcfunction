tellraw @s [{"text": "[The Sky-Marshal] ", "color": "gold", "bold": true}, {"text": "From up here you can see all fifteen kingdoms on a clear day. You can also see the shape they make. Nobody on the ground has ever seen the shape.", "color": "white", "italic": false}]
tellraw @s [{"text": "[The Sky-Marshal] ", "color": "gold", "bold": true}, {"text": "Twelve propellers. Brass and sweat. If you have to ask where to get them you are not ready to fly.", "color": "yellow", "italic": false}]
tellraw @s [{"text": "  Quest 14/15 — bring 12 Propellers  $(4)[Create — airship parts]$() to The Sky-Marshal.", "color": "gray", "italic": true}]
advancement grant @s only aurn:quest/aetherhold/started
playsound minecraft:entity.villager.yes master @s ~ ~ ~ 1 1
