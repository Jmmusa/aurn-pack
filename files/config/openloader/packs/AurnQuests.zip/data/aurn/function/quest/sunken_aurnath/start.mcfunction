tellraw @s [{"text": "[The Archivist of the Drowned] ", "color": "gold", "bold": true}, {"text": "This city is older than every kingdom above it. It does not look abandoned to you, does it. It looks LEFT.", "color": "white", "italic": false}]
tellraw @s [{"text": "[The Archivist of the Drowned] ", "color": "gold", "bold": true}, {"text": "Twelve echo shards. From the deep dark. Bring a light and do not run.", "color": "yellow", "italic": false}]
tellraw @s [{"text": "  Quest 12/15 — bring 12 Echo Shards  $(4)[Deep Dark]$() to The Archivist of the Drowned.", "color": "gray", "italic": true}]
advancement grant @s only aurn:quest/sunken_aurnath/started
playsound minecraft:entity.villager.yes master @s ~ ~ ~ 1 1
