# Aetherhold — Lorekeeper router
execute unless entity @s[advancements={aurn:quest/aetherhold/started=true}] run function aurn:quest/aetherhold/start
execute if entity @s[advancements={aurn:quest/aetherhold/started=true}] unless entity @s[advancements={aurn:quest/aetherhold/done=true}] run function aurn:quest/aetherhold/check
execute if entity @s[advancements={aurn:quest/aetherhold/done=true}] run function aurn:quest/aetherhold/after
