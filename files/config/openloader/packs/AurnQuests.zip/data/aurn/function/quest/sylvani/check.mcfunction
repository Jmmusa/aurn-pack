execute store result score @s aurn_cnt run clear @s minecraft:honeycomb 0
execute if score @s aurn_cnt matches 24.. run function aurn:quest/sylvani/complete
execute if score @s aurn_cnt matches ..23 run tellraw @s [{"text": "[Root-Speaker Aell] ", "color": "gold", "bold": true}, {"text": "Twenty-four honeycomb. Take it kindly or the grove notices.", "color": "yellow", "italic": false}]
execute if score @s aurn_cnt matches ..23 run tellraw @s [{"text": "  Still needed: ", "color": "gray", "italic": true}, {"text": "24 Honeycomb", "color": "yellow", "italic": true}, {"text": "   (you have ", "color": "gray", "italic": true}, {"score": {"name": "@s", "objective": "aurn_cnt"}, "color": "white"}, {"text": ")", "color": "gray", "italic": true}]
