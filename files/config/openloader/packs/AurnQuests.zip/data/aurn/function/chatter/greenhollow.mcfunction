scoreboard players set @s aurn_rng 0
execute store result score @s aurn_rng run random value 1..5
execute if score @s aurn_rng matches 1 run tellraw @s [{"text": "[Villager] ", "color": "gold", "bold": true}, {"text": "Wheat's up again. Everything's up again.", "color": "white", "italic": false}]
execute if score @s aurn_rng matches 2 run tellraw @s [{"text": "[Villager] ", "color": "gold", "bold": true}, {"text": "You're not from here. Don't worry, nobody minds. Much.", "color": "white", "italic": false}]
execute if score @s aurn_rng matches 3 run tellraw @s [{"text": "[Villager] ", "color": "gold", "bold": true}, {"text": "The Miller talks a lot. Some of it's even true.", "color": "white", "italic": false}]
execute if score @s aurn_rng matches 4 run tellraw @s [{"text": "[Villager] ", "color": "gold", "bold": true}, {"text": "Rain's late. Rain's always late.", "color": "white", "italic": false}]
execute if score @s aurn_rng matches 5 run tellraw @s [{"text": "[Villager] ", "color": "gold", "bold": true}, {"text": "Buy something or move along, friend.", "color": "white", "italic": false}]
