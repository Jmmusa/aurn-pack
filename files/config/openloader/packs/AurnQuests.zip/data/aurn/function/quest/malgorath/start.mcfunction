tellraw @s [{"text": "[The Choir-Master] ", "color": "gold", "bold": true}, {"text": "$(4)You have come a long way to be told the truth by the people everyone warned you about.$()  We do not worship a god. We worship the SOUND. We are the only kingdom being honest about it.", "color": "white", "italic": false}]
tellraw @s [{"text": "[The Choir-Master] ", "color": "gold", "bold": true}, {"text": "Three wither skeleton skulls. You are past the point of being asked nicely.", "color": "yellow", "italic": false}]
tellraw @s [{"text": "  Quest 15/15 — bring 3 Wither Skeleton Skulls to The Choir-Master.", "color": "gray", "italic": true}]
advancement grant @s only aurn:quest/malgorath/started
playsound minecraft:entity.villager.yes master @s ~ ~ ~ 1 1
