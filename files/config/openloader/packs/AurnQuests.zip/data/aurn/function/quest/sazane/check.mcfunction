execute store result score @s aurn_cnt run clear @s minecraft:pink_petals 0
execute if score @s aurn_cnt matches 32.. run function aurn:quest/sazane/complete
execute if score @s aurn_cnt matches ..31 run tellraw @s [{"text": "[The Petal-Sworn] ", "color": "gold", "bold": true}, {"text": "Thirty-two petals. Cut, not fallen. Fallen petals have already given up.", "color": "yellow", "italic": false}]
execute if score @s aurn_cnt matches ..31 run tellraw @s [{"text": "  Still needed: ", "color": "gray", "italic": true}, {"text": "32 Pink Petals", "color": "yellow", "italic": true}, {"text": "   (you have ", "color": "gray", "italic": true}, {"score": {"name": "@s", "objective": "aurn_cnt"}, "color": "white"}, {"text": ")", "color": "gray", "italic": true}]
