execute store result score @s aurn_cnt run clear @s minecraft:gold_ingot 0
execute if score @s aurn_cnt matches 16.. run function aurn:quest/dust_hollow/complete
execute if score @s aurn_cnt matches ..15 run tellraw @s [{"text": "[The Seam-Finder] ", "color": "gold", "bold": true}, {"text": "Sixteen gold. I do not care where from. Out here nobody asks.", "color": "yellow", "italic": false}]
execute if score @s aurn_cnt matches ..15 run tellraw @s [{"text": "  Still needed: ", "color": "gray", "italic": true}, {"text": "16 Gold Ingots", "color": "yellow", "italic": true}, {"text": "   (you have ", "color": "gray", "italic": true}, {"score": {"name": "@s", "objective": "aurn_cnt"}, "color": "white"}, {"text": ")", "color": "gray", "italic": true}]
