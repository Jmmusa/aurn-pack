execute store result score @s aurn_cnt run clear @s minecraft:prismarine_crystals 0
execute if score @s aurn_cnt matches 32.. run function aurn:quest/isar_thal/complete
execute if score @s aurn_cnt matches ..31 run tellraw @s [{"text": "[The Bell-Warden] ", "color": "gold", "bold": true}, {"text": "Thirty-two prismarine crystals. From the monument, not the shallows.", "color": "yellow", "italic": false}]
execute if score @s aurn_cnt matches ..31 run tellraw @s [{"text": "  Still needed: ", "color": "gray", "italic": true}, {"text": "32 Prismarine Crystals", "color": "yellow", "italic": true}, {"text": "   (you have ", "color": "gray", "italic": true}, {"score": {"name": "@s", "objective": "aurn_cnt"}, "color": "white"}, {"text": ")", "color": "gray", "italic": true}]
