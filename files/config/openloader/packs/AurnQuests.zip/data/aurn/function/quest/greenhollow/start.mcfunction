tellraw @s [{"text": "[The Miller] ", "color": "gold", "bold": true}, {"text": "Everyone here will tell you the world began with a sound. They say it like they were there. None of them were.", "color": "white", "italic": false}]
tellraw @s [{"text": "[The Miller] ", "color": "gold", "bold": true}, {"text": "Bring me sixteen wheat. I am not being clever. The mill is empty and people are hungry.", "color": "yellow", "italic": false}]
tellraw @s [{"text": "  Quest 1/15 — bring 16 Wheat to The Miller.", "color": "gray", "italic": true}]
advancement grant @s only aurn:quest/greenhollow/started
playsound minecraft:entity.villager.yes master @s ~ ~ ~ 1 1
