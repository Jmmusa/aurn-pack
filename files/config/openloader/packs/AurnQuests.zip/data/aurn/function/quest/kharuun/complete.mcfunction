clear @s minecraft:iron_ingot 12
tellraw @s [{"text": "[Ledger-Keeper Haruun] ", "color": "gold", "bold": true}, {"text": "Down at the eighth seam the picks make no echo. Not a soft echo. NONE. Something down there is absorbing it. We stopped digging. We did not stop listening.", "color": "white", "italic": false}]
tellraw @s [{"text": "  Ledger-Keeper Haruun gives you rusted chainmail, an iron buckler and a good pick.", "color": "green", "italic": true}]
give @s magistuarmory:rustedchainmail_chestplate
give @s magistuarmory:iron_buckler
give @s minecraft:iron_pickaxe
advancement grant @s only aurn:quest/kharuun/done
playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1 1
