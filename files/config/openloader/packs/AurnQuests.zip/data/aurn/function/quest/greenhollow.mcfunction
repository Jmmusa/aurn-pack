# Greenhollow — Lorekeeper router
execute unless entity @s[advancements={aurn:quest/greenhollow/started=true}] run function aurn:quest/greenhollow/start
execute if entity @s[advancements={aurn:quest/greenhollow/started=true}] unless entity @s[advancements={aurn:quest/greenhollow/done=true}] run function aurn:quest/greenhollow/check
execute if entity @s[advancements={aurn:quest/greenhollow/done=true}] run function aurn:quest/greenhollow/after
