tellraw @s [{"text": "[The Licensed Archivist] ", "color": "gold", "bold": true}, {"text": "Two rulers. One throne. Every account of the beginning must be filed in triplicate and approved by both. So there are two official versions and they do not match.", "color": "white", "italic": false}]
tellraw @s [{"text": "[The Licensed Archivist] ", "color": "gold", "bold": true}, {"text": "Thirty-two books. Bound, not loose. Filing requires bound books.", "color": "yellow", "italic": false}]
tellraw @s [{"text": "  Quest 8/15 — bring 32 Books to The Licensed Archivist.", "color": "gray", "italic": true}]
advancement grant @s only aurn:quest/twin_crown/started
playsound minecraft:entity.villager.yes master @s ~ ~ ~ 1 1
