# Sylvani — Lorekeeper router
execute unless entity @s[advancements={aurn:quest/sylvani/started=true}] run function aurn:quest/sylvani/start
execute if entity @s[advancements={aurn:quest/sylvani/started=true}] unless entity @s[advancements={aurn:quest/sylvani/done=true}] run function aurn:quest/sylvani/check
execute if entity @s[advancements={aurn:quest/sylvani/done=true}] run function aurn:quest/sylvani/after
