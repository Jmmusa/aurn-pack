clear @s minecraft:paper 48
tellraw @s [{"text": "[Cartographer Yset] ", "color": "gold", "bold": true}, {"text": "I have surveyed a ninth Spire. It is not on any map because I did not put it on any map. It is the only one making no sound. I have not gone back.", "color": "white", "italic": false}]
tellraw @s [{"text": "  Cartographer Yset gives you a knight's plate, a face helm and a fresh map.", "color": "green", "italic": true}]
give @s magistuarmory:knight_chestplate
give @s magistuarmory:face_helmet
give @s minecraft:map
advancement grant @s only aurn:quest/nasiri/done
playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1 1
