tellraw @s [{"text": "[Ledger-Keeper Haruun] ", "color": "gold", "bold": true}, {"text": "We do not dig for ore. We dig because the deeper stone is QUIETER. My grandfather wrote that down and then crossed it out.", "color": "white", "italic": false}]
tellraw @s [{"text": "[Ledger-Keeper Haruun] ", "color": "gold", "bold": true}, {"text": "Twelve iron. Smelted, not raw. I keep a ledger and the ledger does not accept excuses.", "color": "yellow", "italic": false}]
tellraw @s [{"text": "  Quest 2/15 — bring 12 Iron Ingots to Ledger-Keeper Haruun.", "color": "gray", "italic": true}]
advancement grant @s only aurn:quest/kharuun/started
playsound minecraft:entity.villager.yes master @s ~ ~ ~ 1 1
