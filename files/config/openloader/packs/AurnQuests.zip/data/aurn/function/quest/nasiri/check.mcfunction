execute store result score @s aurn_cnt run clear @s minecraft:paper 0
execute if score @s aurn_cnt matches 48.. run function aurn:quest/nasiri/complete
execute if score @s aurn_cnt matches ..47 run tellraw @s [{"text": "[Cartographer Yset] ", "color": "gold", "bold": true}, {"text": "Forty-eight paper. A cartographer without paper is just a man with opinions.", "color": "yellow", "italic": false}]
execute if score @s aurn_cnt matches ..47 run tellraw @s [{"text": "  Still needed: ", "color": "gray", "italic": true}, {"text": "48 Paper", "color": "yellow", "italic": true}, {"text": "   (you have ", "color": "gray", "italic": true}, {"score": {"name": "@s", "objective": "aurn_cnt"}, "color": "white"}, {"text": ")", "color": "gray", "italic": true}]
