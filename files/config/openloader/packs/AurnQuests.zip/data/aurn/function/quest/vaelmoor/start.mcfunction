tellraw @s [{"text": "[The Lantern-Keeper] ", "color": "gold", "bold": true}, {"text": "We keep lanterns lit not to see. To be seen. There is a difference and you will learn it here.", "color": "white", "italic": false}]
tellraw @s [{"text": "[The Lantern-Keeper] ", "color": "gold", "bold": true}, {"text": "Eight dark ingots. You will need a Dark Altar and the patience to use it. That is the point.", "color": "yellow", "italic": false}]
tellraw @s [{"text": "  Quest 9/15 — bring 8 Dark Ingots  $(4)[Goety ritual craft]$() to The Lantern-Keeper.", "color": "gray", "italic": true}]
advancement grant @s only aurn:quest/vaelmoor/started
playsound minecraft:entity.villager.yes master @s ~ ~ ~ 1 1
