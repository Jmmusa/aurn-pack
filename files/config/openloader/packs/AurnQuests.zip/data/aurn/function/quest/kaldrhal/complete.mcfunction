clear @s minecraft:blue_ice 16
tellraw @s [{"text": "[The Frost-Warden] ", "color": "gold", "bold": true}, {"text": "Something is frozen under the third shelf. It has a shape. We do not dig it out because while it is frozen it is not screaming.", "color": "white", "italic": false}]
tellraw @s [{"text": "  The Frost-Warden gives you cold-forged mail, a norman helm and an iron spear.", "color": "green", "italic": true}]
give @s magistuarmory:chainmail_chestplate
give @s magistuarmory:rustednorman_helmet
give @s simplyswords:iron_spear
advancement grant @s only aurn:quest/kaldrhal/done
playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1 1
