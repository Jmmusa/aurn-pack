clear @s minecraft:gold_ingot 16
tellraw @s [{"text": "[The Seam-Finder] ", "color": "gold", "bold": true}, {"text": "There is a seam in the AIR, west of the dry wash. It is about the height of a door. Look at it from the side and it is not there. Look at it straight on and you can hear a crowd.", "color": "white", "italic": false}]
tellraw @s [{"text": "  The Seam-Finder gives you a brigandine, a kite shield and golden apples.", "color": "green", "italic": true}]
give @s magistuarmory:brigandine_chestplate
give @s magistuarmory:iron_kiteshield
give @s minecraft:golden_apple 3
advancement grant @s only aurn:quest/dust_hollow/done
playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1 1
