execute store result score @s aurn_cnt run clear @s minecraft:iron_ingot 0
execute if score @s aurn_cnt matches 12.. run function aurn:quest/kharuun/complete
execute if score @s aurn_cnt matches ..11 run tellraw @s [{"text": "[Ledger-Keeper Haruun] ", "color": "gold", "bold": true}, {"text": "Twelve iron. Smelted, not raw. I keep a ledger and the ledger does not accept excuses.", "color": "yellow", "italic": false}]
execute if score @s aurn_cnt matches ..11 run tellraw @s [{"text": "  Still needed: ", "color": "gray", "italic": true}, {"text": "12 Iron Ingots", "color": "yellow", "italic": true}, {"text": "   (you have ", "color": "gray", "italic": true}, {"score": {"name": "@s", "objective": "aurn_cnt"}, "color": "white"}, {"text": ")", "color": "gray", "italic": true}]
