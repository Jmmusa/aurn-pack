# Sunken Aurnath — Lorekeeper router
execute unless entity @s[advancements={aurn:quest/sunken_aurnath/started=true}] run function aurn:quest/sunken_aurnath/start
execute if entity @s[advancements={aurn:quest/sunken_aurnath/started=true}] unless entity @s[advancements={aurn:quest/sunken_aurnath/done=true}] run function aurn:quest/sunken_aurnath/check
execute if entity @s[advancements={aurn:quest/sunken_aurnath/done=true}] run function aurn:quest/sunken_aurnath/after
