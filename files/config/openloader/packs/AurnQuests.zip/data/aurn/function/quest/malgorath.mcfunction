# Malgorath — Lorekeeper router
execute unless entity @s[advancements={aurn:quest/malgorath/started=true}] run function aurn:quest/malgorath/start
execute if entity @s[advancements={aurn:quest/malgorath/started=true}] unless entity @s[advancements={aurn:quest/malgorath/done=true}] run function aurn:quest/malgorath/check
execute if entity @s[advancements={aurn:quest/malgorath/done=true}] run function aurn:quest/malgorath/after
