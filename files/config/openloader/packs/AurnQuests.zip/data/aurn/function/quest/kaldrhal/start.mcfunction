tellraw @s [{"text": "[The Frost-Warden] ", "color": "gold", "bold": true}, {"text": "The first Echo struck the glacier and STOPPED. That is why we are cold. That is why we are still here. The priests of the south will tell you otherwise.", "color": "white", "italic": false}]
tellraw @s [{"text": "[The Frost-Warden] ", "color": "gold", "bold": true}, {"text": "Sixteen blue ice. Cut it yourself. Ice given is not ice earned.", "color": "yellow", "italic": false}]
tellraw @s [{"text": "  Quest 3/15 — bring 16 Blue Ice to The Frost-Warden.", "color": "gray", "italic": true}]
advancement grant @s only aurn:quest/kaldrhal/started
playsound minecraft:entity.villager.yes master @s ~ ~ ~ 1 1
