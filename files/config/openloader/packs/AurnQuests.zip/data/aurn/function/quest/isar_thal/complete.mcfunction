clear @s minecraft:prismarine_crystals 32
tellraw @s [{"text": "[The Bell-Warden] ", "color": "gold", "bold": true}, {"text": "It heard. It has been trying to repeat what it heard for six hundred years and its mouth is not shaped for the sound. That is what you can hear under the water. That is not the sea.", "color": "white", "italic": false}]
tellraw @s [{"text": "  The Bell-Warden gives you gothic plate, a steel kite shield and a heart of the sea.", "color": "green", "italic": true}]
give @s magistuarmory:gothic_chestplate
give @s magistuarmory:steel_kiteshield
give @s minecraft:heart_of_the_sea
advancement grant @s only aurn:quest/isar_thal/done
playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1 1
