clear @s create:propeller 12
tellraw @s [{"text": "[The Sky-Marshal] ", "color": "gold", "bold": true}, {"text": "The kingdoms are arranged in a ring. Nine points on that ring are exact. The other six were built later, by people guessing. We are one of the guesses. The ring is centred on Malgorath.", "color": "white", "italic": false}]
tellraw @s [{"text": "  The Sky-Marshal gives you jousting plate, Caelestis, and wings.", "color": "green", "italic": true}]
give @s magistuarmory:jousting_chestplate
give @s simplyswords:caelestis
give @s minecraft:elytra
advancement grant @s only aurn:quest/aetherhold/done
playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1 1
