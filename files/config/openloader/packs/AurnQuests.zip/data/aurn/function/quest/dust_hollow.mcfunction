# Dust Hollow — Lorekeeper router
execute unless entity @s[advancements={aurn:quest/dust_hollow/started=true}] run function aurn:quest/dust_hollow/start
execute if entity @s[advancements={aurn:quest/dust_hollow/started=true}] unless entity @s[advancements={aurn:quest/dust_hollow/done=true}] run function aurn:quest/dust_hollow/check
execute if entity @s[advancements={aurn:quest/dust_hollow/done=true}] run function aurn:quest/dust_hollow/after
