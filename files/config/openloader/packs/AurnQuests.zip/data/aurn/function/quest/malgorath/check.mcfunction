execute store result score @s aurn_cnt run clear @s minecraft:wither_skeleton_skull 0
execute if score @s aurn_cnt matches 3.. run function aurn:quest/malgorath/complete
execute if score @s aurn_cnt matches ..2 run tellraw @s [{"text": "[The Choir-Master] ", "color": "gold", "bold": true}, {"text": "Three wither skeleton skulls. You are past the point of being asked nicely.", "color": "yellow", "italic": false}]
execute if score @s aurn_cnt matches ..2 run tellraw @s [{"text": "  Still needed: ", "color": "gray", "italic": true}, {"text": "3 Wither Skeleton Skulls", "color": "yellow", "italic": true}, {"text": "   (you have ", "color": "gray", "italic": true}, {"score": {"name": "@s", "objective": "aurn_cnt"}, "color": "white"}, {"text": ")", "color": "gray", "italic": true}]
