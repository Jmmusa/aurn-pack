clear @s minecraft:wither_skeleton_skull 3
tellraw @s [{"text": "[The Choir-Master] ", "color": "gold", "bold": true}, {"text": "$(4)Everything you were told was one person's guess repeated for six hundred years.$()  Here is what is not a guess: the sound is still being made. It did not happen. It is HAPPENING. And something in this fortress has been singing along to keep it company. Go and meet it.", "color": "white", "italic": false}]
tellraw @s [{"text": "  The Choir-Master gives you kastenbrust plate, the Harbinger, and netherite.", "color": "green", "italic": true}]
give @s magistuarmory:kastenbrust_chestplate
give @s simplyswords:harbinger
give @s minecraft:netherite_ingot 2
advancement grant @s only aurn:quest/malgorath/done
playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1 1
