clear @s minecraft:wheat 16
tellraw @s [{"text": "[The Miller] ", "color": "gold", "bold": true}, {"text": "You wanted something deeper than grain, didn't you. Here is what I actually know: the sound had a NAME before it was a sound. Nobody in this village will say it. Ask the ones who dig.", "color": "white", "italic": false}]
tellraw @s [{"text": "  The Miller gives you a padded gambeson, a buckler and bread.", "color": "green", "italic": true}]
give @s magistuarmory:gambeson_chestplate
give @s magistuarmory:copper_buckler
give @s minecraft:bread 16
advancement grant @s only aurn:quest/greenhollow/done
playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1 1
