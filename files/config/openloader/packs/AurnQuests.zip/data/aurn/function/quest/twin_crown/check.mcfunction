execute store result score @s aurn_cnt run clear @s minecraft:book 0
execute if score @s aurn_cnt matches 32.. run function aurn:quest/twin_crown/complete
execute if score @s aurn_cnt matches ..31 run tellraw @s [{"text": "[The Licensed Archivist] ", "color": "gold", "bold": true}, {"text": "Thirty-two books. Bound, not loose. Filing requires bound books.", "color": "yellow", "italic": false}]
execute if score @s aurn_cnt matches ..31 run tellraw @s [{"text": "  Still needed: ", "color": "gray", "italic": true}, {"text": "32 Books", "color": "yellow", "italic": true}, {"text": "   (you have ", "color": "gray", "italic": true}, {"score": {"name": "@s", "objective": "aurn_cnt"}, "color": "white"}, {"text": ")", "color": "gray", "italic": true}]
