clear @s goety:dark_ingot 8
tellraw @s [{"text": "[The Lantern-Keeper] ", "color": "gold", "bold": true}, {"text": "The things in the fog are not hunting. They are WAITING. They have the posture of a congregation. We built the lanterns so they would look at us instead of at whatever they are facing.", "color": "white", "italic": false}]
tellraw @s [{"text": "  The Lantern-Keeper gives you black iron plate, a black iron helm and soul lanterns.", "color": "green", "italic": true}]
give @s goety:black_iron_chestplate
give @s goety:black_iron_helmet
give @s minecraft:soul_lantern 8
advancement grant @s only aurn:quest/vaelmoor/done
playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1 1
