execute store result score @s aurn_cnt run clear @s minecraft:wheat 0
execute if score @s aurn_cnt matches 16.. run function aurn:quest/greenhollow/complete
execute if score @s aurn_cnt matches ..15 run tellraw @s [{"text": "[The Miller] ", "color": "gold", "bold": true}, {"text": "Bring me sixteen wheat. I am not being clever. The mill is empty and people are hungry.", "color": "yellow", "italic": false}]
execute if score @s aurn_cnt matches ..15 run tellraw @s [{"text": "  Still needed: ", "color": "gray", "italic": true}, {"text": "16 Wheat", "color": "yellow", "italic": true}, {"text": "   (you have ", "color": "gray", "italic": true}, {"score": {"name": "@s", "objective": "aurn_cnt"}, "color": "white"}, {"text": ")", "color": "gray", "italic": true}]
